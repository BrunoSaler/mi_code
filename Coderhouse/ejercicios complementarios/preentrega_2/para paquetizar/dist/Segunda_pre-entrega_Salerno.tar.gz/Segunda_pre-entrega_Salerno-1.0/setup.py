from setuptools import setup

setup (
name = "Segunda_pre-entrega_Salerno",
version = "1.0",
description = "Segunda pre-entrega delcurso Python de Coderhouse",
author = "Bruno Salerno",
author_email="bruno.salerno97@gmail.com",
packages = ["preentrega2salerno", "preentrega2salerno.Primera_preentrega_Salerno"]
)